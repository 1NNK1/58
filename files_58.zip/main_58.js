console.log('#57. JavaScript homework example file');

import { createHash, pbkdf2Sync, timingSafeEqual } from 'node:crypto';

/**
 * Залежності за замовчуванням. Для тестів (Jest) їх можна підмінити через
 * останній необов'язковий параметр кожної функції.
 */
const defaultDeps = { createHash, pbkdf2Sync, timingSafeEqual };

/**
 * Перевіряє, що значення є рядком.
 * @param {unknown} value Значення.
 * @param {string} name Назва параметра для повідомлення про помилку.
 * @throws {TypeError} Якщо значення не є рядком.
 */
function assertString(value, name) {
  if (typeof value !== 'string') {
    throw new TypeError(`${name} має бути рядком`);
  }
}

/**
 * Перевіряє, що значення є додатним цілим числом.
 * @param {unknown} value Значення.
 * @param {string} name Назва параметра для повідомлення про помилку.
 * @throws {TypeError} Якщо значення не є додатним цілим числом.
 */
function assertPositiveInteger(value, name) {
  if (!Number.isInteger(value) || value <= 0) {
    throw new TypeError(`${name} має бути додатним цілим числом`);
  }
}

/*
 *
 * #1
 *
 * Технічне завдання для розробки функції "generateHash"
 *
 * Задача:
 * Розробити функцію, що використовує криптографічний алгоритм SHA-256 для генерації хешу з заданого рядка. Функція має бути реалізована так, щоб її можна було легко тестувати, забезпечувати точність та безпеку генерації хешу.
 *
 * Функціональні вимоги:
 * 1. Вхідні параметри:
 *  - `input`: Рядок, який потрібно хешувати.
 *
 * 2. Вихідні дані:
 *  - Функція повертає хеш заданого рядка у форматі шістнадцяткового рядка.
 *
 * 3. Безпека:
 *  - Використання криптографічно стійкого алгоритму SHA-256.
 *
 * Технічні вимоги:
 * - Використання сучасних можливостей JavaScript (ES6+), включаючи модулі ESM для легкої інтеграції та тестування.
 * - Функція має бути написана таким чином, щоб вона могла бути експортована та використана в інших частинах програми або тестових сценаріях.
 * - Забезпечення документації коду з описом параметрів, процесу роботи та прикладами використання.
 * - Підготовка функції для можливості легкого мокування та тестування за допомогою JEST.
 *
 */

/**
 * Генерує SHA-256 хеш рядка.
 *
 * @param {string} input Рядок, який потрібно захешувати (кодування UTF-8).
 * @param {typeof defaultDeps} [deps] Залежності (для мокування в тестах).
 * @returns {string} Хеш у вигляді шістнадцяткового рядка (64 символи).
 * @throws {TypeError} Якщо input не є рядком.
 *
 * @example
 * generateHash('Hello, World!');
 * // 'dffd6021bb2bd5b0af676290809ec3a53191dd81c7f70a4b28688a362182986f'
 */
function generateHash(input, deps = defaultDeps) {
  assertString(input, 'input');
  return deps.createHash('sha256').update(input, 'utf8').digest('hex');
}

// console.log(generateHash('Hello, World!'))

/*
 *
 * #2
 *
 * Технічне завдання для розробки функції "generatePasswordHash"
 *
 * Задача:
 * Розробити функцію, що використовує PBKDF2 алгоритм для генерації хешу паролю з використанням сілі. Функція повинна забезпечити високий рівень безпеки збережених паролів і бути легкою для тестування та інтеграції в більші системи.
 *
 * Функціональні вимоги:
 * 1. Вхідні параметри:
 *  - `password`: Рядок пароля, який потрібно захешувати.
 *  - `salt`: Сіль, яка використовується для генерації хешу, має бути у форматі рядка.
 *  - `iterations`: Кількість ітерацій хешування (дефолтне значення 10000).
 *  - `keylen`: Довжина ключа у байтах (дефолтне значення 64).
 *  - `digest`: Алгоритм хешування (дефолтне значення 'sha512').
 *
 * 2. Вихідні дані:
 *  - Функція повертає хеш заданого пароля у форматі шістнадцяткового рядка.
 *
 * 3. Безпека:
 *  - Використання алгоритму PBKDF2 для забезпечення стійкості до атак брутфорсом і rainbow tables.
 *
 * Технічні вимоги:
 * - Використання сучасних можливостей JavaScript (ES6+), включаючи модулі ESM для легкої інтеграції та тестування.
 * - Код має бути чистим, добре структурованим, з логічною структурою та зрозумілими назвами змінних та функцій.
 * - Підготовка функції для легкої інтеграції у тести, використовуючи JEST для мокування залежностей і перевірки поведінки функції.
 *
 */

/**
 * Генерує хеш пароля за алгоритмом PBKDF2 з використанням солі.
 * Для кожного пароля слід використовувати власну випадкову сіль
 * (наприклад, randomBytes(16).toString('hex')) та зберігати її разом з хешем.
 *
 * @param {string} password Пароль.
 * @param {string} salt Сіль (рядок).
 * @param {number} [iterations=10000] Кількість ітерацій.
 * @param {number} [keylen=64] Довжина ключа в байтах.
 * @param {string} [digest='sha512'] Алгоритм хешування.
 * @param {typeof defaultDeps} [deps] Залежності (для мокування в тестах).
 * @returns {string} Хеш у вигляді шістнадцяткового рядка (довжина keylen * 2).
 * @throws {TypeError} Якщо password чи salt не є рядками, а iterations або keylen
 *   не є додатними цілими числами.
 *
 * @example
 * const salt = randomBytes(16).toString('hex');
 * const hash = generatePasswordHash('superSecret123', salt);
 */
function generatePasswordHash(
  password,
  salt,
  iterations = 10000,
  keylen = 64,
  digest = 'sha512',
  deps = defaultDeps,
) {
  assertString(password, 'password');
  assertString(salt, 'salt');
  assertPositiveInteger(iterations, 'iterations');
  assertPositiveInteger(keylen, 'keylen');
  return deps.pbkdf2Sync(password, salt, iterations, keylen, digest).toString('hex');
}

// Застосування функції
// const password = 'superSecret123'
// const salt = randomBytes(16).toString('hex')
// const hash = generatePasswordHash(password, salt)

/*
 *
 * #3
 *
 * Технічне завдання для розробки функції "verifyPassword"
 *
 * Задача:
 * Розробити функцію, яка перевіряє відповідність введеного пароля збереженому хешу, використовуючи алгоритм PBKDF2. Функція повинна підтверджувати або спростовувати відповідність на основі переданих параметрів солі, ітерацій, довжини ключа та алгоритму хешування.
 *
 * Функціональні вимоги:
 * 1. Вхідні параметри:
 *  - `inputPassword`: Рядок, введений користувачем як пароль.
 *  - `storedHash`: Рядок, що містить збережений хеш паролю.
 *  - `salt`: Рядок, який представляє сіль, використану для генерації збереженого хешу.
 *  - `iterations`: Кількість ітерацій хешування (дефолтне значення 10000).
 *  - `keylen`: Довжина ключа у байтах (дефолтне значення 64).
 *  - `digest`: Алгоритм хешування (дефолтне значення 'sha512').
 *
 * 2. Результат:
 *  - Функція повертає булеве значення: `true`, якщо хеш введеного паролю співпадає з збереженим хешем; `false` — в інших випадках.
 *
 * 3. Безпека:
 *  - Використання надійних криптографічних методів для забезпечення захисту відомостей про паролі.
 *
 * Технічні вимоги:
 * - Використання сучасних можливостей JavaScript (ES6+), зокрема модулів ECMAScript для імпорту та експорту функцій.
 * - Чистий, добре структурований код з логічною структурою та зрозумілими назвами змінних і функцій.
 * - Підготовка функції для легкої інтеграції у тести, використовуючи JEST для мокування залежностей і перевірки поведінки функції.
 *
 */

/**
 * Перевіряє пароль за збереженим хешем (PBKDF2). Порівняння виконується
 * за постійний час (timingSafeEqual), що захищає від атак за часом відповіді.
 *
 * @param {string} inputPassword Пароль, введений користувачем.
 * @param {string} storedHash Збережений хеш (шістнадцятковий рядок).
 * @param {string} salt Сіль, використана при створенні хешу.
 * @param {number} [iterations=10000] Кількість ітерацій.
 * @param {number} [keylen=64] Довжина ключа в байтах.
 * @param {string} [digest='sha512'] Алгоритм хешування.
 * @param {typeof defaultDeps} [deps] Залежності (для мокування в тестах).
 * @returns {boolean} true, якщо пароль збігається з хешем; інакше false
 *   (зокрема, якщо storedHash має некоректний формат або довжину).
 * @throws {TypeError} Якщо вхідні параметри мають некоректний тип.
 *
 * @example
 * const isCorrect = verifyPassword('superSecret123', hash, salt);
 * console.log(isCorrect ? 'Пароль вірний.' : 'Пароль невірний.');
 */
function verifyPassword(
  inputPassword,
  storedHash,
  salt,
  iterations = 10000,
  keylen = 64,
  digest = 'sha512',
  deps = defaultDeps,
) {
  assertString(storedHash, 'storedHash');
  const inputHash = generatePasswordHash(inputPassword, salt, iterations, keylen, digest, deps);

  if (!/^[0-9a-f]+$/i.test(storedHash) || storedHash.length !== inputHash.length) {
    return false;
  }

  return deps.timingSafeEqual(Buffer.from(inputHash, 'hex'), Buffer.from(storedHash, 'hex'));
}

// Застосування функції
// const inputPassword = 'superSecret123'
// const isCorrect = verifyPassword(inputPassword, hash, salt)
// console.log(isCorrect ? 'Пароль вірний.' : 'Пароль невірний.')

export { generateHash, generatePasswordHash, verifyPassword };
